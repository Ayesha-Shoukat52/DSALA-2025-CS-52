﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using task1DSA;
namespace task1DSA
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student();
            student.SetSName("Fatima");
            student.SetFatherName("Zahid");
            student.SetAge(19);
            student.SetID(44);
            Console.WriteLine(student.GetSName());
            Console.WriteLine(student.GetFatherName());
            Console.WriteLine(student.GetAge());
            Console.WriteLine(student.GetID());
            Console.WriteLine(student.ToString());

            Detail detail = new Detail();
            detail.GetDetail();
            UniStudent uni =new UniStudent();
            uni.GetRole();

        }
    }

}
