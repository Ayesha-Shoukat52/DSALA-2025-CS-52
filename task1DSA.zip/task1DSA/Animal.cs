﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task1DSA
{
    internal class student
    {
        public virtual void GetDetail()
        {
            Console.WriteLine(" This is a student of semester 3.");

        }
        public virtual void GetRole()
        {
            Console.WriteLine("I am A student. ");

        }

    }
    class Detail : student
    {
        public override void GetDetail()
        {
            Console.WriteLine("she is a uni student .");

        }
    }
    class UniStudent : student
    {
        public override void GetRole()
        {
            {
                Console.WriteLine("I am University Student.");

            }
        }
    }
    
}
