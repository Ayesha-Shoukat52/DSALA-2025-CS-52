﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task1DSA
{
    internal class Student
    {
        private string SName;
        private string FatherName;
        private int Age;
        private int ID;
       
        public void SetSName(string sName)
        {
           SName = sName;  
        }
        public string GetSName()
        {
            return SName;
        }
        public void SetFatherName(string fatherName)
        {
            FatherName = fatherName;
        }
        public string GetFatherName()
        {
            return FatherName;
        }
        public void SetAge(int age)
        {
            Age = age;
        }
        public int GetAge()
        {
            return Age;
        }
        public void SetID(int id)
        {
            ID = id;
        }
        public int GetID()
        {
           return ID;  
        }
        public Student(string  sName,string fatherName,int age,int id)
        {
            this.SName = sName;
            this.FatherName = fatherName;
            this.Age = age;
            this.ID = id;
        }
        public Student()
        {
        }
        public override string ToString()
        {
           return $"Name: {SName},Father Name: {FatherName},Age: {Age},ID: {ID}";
            
        }

    }
    
}
